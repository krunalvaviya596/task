const port = 8080;
const hostname = 'localhost';

const path = require('path');
const express = require('express');
const app = express();
const express_validator = require('express-validator');
const usercontroller = require('./public/js/usercontroller');
const user = require('./public/js/userschema');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');

const Database = require('./public/js/connection.js')
const sendMail = require('./public/js/sendmail')

app.use(express.static(__dirname + "/public"))
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: false }))

app.set('views', './views');


const cookieParser = require('cookie-parser');
const { verify } = require('crypto');
app.use(cookieParser());



const autologin = async (req, res, next) => {
    if (!req.cookies.login) {
        
        res.sendFile(__dirname + '/views/login.html');
    }
    const krunal = req.cookies.login;
    try {
        jwt.verify(krunal, "randomString");
        res.sendFile(__dirname + '/views/welcome.html');
    } catch (error) {
        
        res.sendFile(__dirname + '/views/login.html');
    }
}


//how to logout button work node code?

app.post('/logout', (req, res) => {
    res.clearCookie('login');
    res.redirect('/');
});



app.get('/', autologin, (req, res) => {
});

app.get('/signup', (req, res) => {
    res.sendFile(__dirname + '/views/verify.html')
});
app.get('/signupform/:Userid/:token', usercontroller.auth, (req, res) => {
    res.sendFile(__dirname + '/views/signupform.html')
});
app.get('/forgot', (req, res) => {
    res.sendFile(__dirname + '/views/forgot.html')
});
app.get("/forgot/:Userid/:token", usercontroller.auth, (req, res) => {
    res.sendFile(__dirname + "/views/forgotpassword.html")
});
app.get('/welcome', autologin, (req, res) => {
    res.sendFile(__dirname + '/views/welcome.html')
})

app.post("/send", sendMail.sendMail);

app.post("/register", usercontroller.register)

app.post("/login", usercontroller.login)

app.post("/forgot", sendMail.forgot);

app.post("/forgotpassword", sendMail.forgotpassword);


app.listen(port, hostname, () => {
    console.log(`server running at http://${hostname}:${port}/`);
})