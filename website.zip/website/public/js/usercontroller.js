const user = require("../js/userschema")
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
let validator = require('validator')
const res = require("express/lib/response")
const { check, validationResult} = require("express-validator/check");
const { findOne } = require("../js/userschema")
const cookieParser = require('cookie-parser')
const { json } = require("body-parser")
const session = require('express-session');
const flash = require('connect-flash');
const { response } = require("express")


const register = async (req, res) => {

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            errors: errors.array()
      });
    }
      const {firstname,lastname,birthdate,country,password,hiddenUserid,hiddentoken} = req.body;
      const id = hiddenUserid; 
      const token = hiddentoken;
      const salt = await bcrypt.genSalt(10);
      const hashedpassword = await bcrypt.hash(password, salt);
      // console.log("Html post method:-"+id);
      // console.log("Html post method:-"+token);
      // User = new user({firstname,lastname,birthdate,country,password});
      // console.log("hashedpassword:-"+ hashedpassword);
      
      try {
        let User = await user.findById({_id:id});
        if (!User) {
          res.send("register error")
        } else {
          // console.log(User);
          // console.log(User._id);
          // console.log(User.id);
          // console.log("Html post method:-"+id);
          const token = jwt.sign({id: User._id},"randomString", {expiresIn: "24h"})
          res.cookie("login" ,token, {MaxAge: 24 * 60 * 60 ,httpOnly: true, secure: true})
          await user.findOneAndUpdate({_id:id}, {$set: { firstname:firstname, lastname:lastname, birthdate:birthdate, country:country, password:hashedpassword,token:token}})
          res.redirect("/welcome")
        }
      } catch (error) {
        res.send("catch error: " + error)
      }
}

const login = async (req, res) => {
  
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      errors: errors.array()
    });
  }
  const { email, password } = req.body;      
  
  try {
    let User = await user.findOne({
      email                
    });    
    
    if (!User){
      // return res.redirect("/")
      res.status(400).send("User Not Exist");
    }else {
          const isMatch = await bcrypt.compare(password, User.password);
          console.log(isMatch);
          if (!isMatch){
            // res.status(401).send("Password incorrect");
            const message = "Password incorrect";
            // res.status(401).send("Password incorrect");
            // console.log(email);
            req.flash("message", "Password incorrect");
            res.redirect("/")
            // res.redirect("/");
            
            
          }else{
            
            const token = jwt.sign({id: User._id},"randomString", {expiresIn: "24h"})
            res.cookie("login" ,token, {MaxAge: 24 * 60 * 60 ,httpOnly: true, secure: true})
            
            await user.findOneAndUpdate({_id:User._id}, {$set: {token:token}})
            
            res.redirect("/welcome")
          }
    }
  } 
  catch (e) {
    res.status(500).send("Server Error");
  }
}

const auth = async (req, res,next) => {
  const {token} = req.params;
  const {Userid} = req.params;
  console.log(Userid);
  console.log(token);
  try {
    const User = await user.findById({_id:Userid})
      const verify = jwt.verify(token,"randomString",(err,verify)=>{
        if (err) {
            res.send("token expire")
        }else{
            next();
        }
      });
  }catch (error) {
    res.send("user not found");
  }
}

module.exports = {
  register,
  login,
  auth,
}










const register1 = (req, res, next) => {
  bcrypt.hash(req.body.password, 10, function (err, hashedpass) {
    if (err) {
      res.json({
        error: err
      })
    }

    let User = new user({
      firstname: req.body.firstname,
      lastname: req.body.lastname,
      fullname: req.body.firstname + ' ' + req.body.lastname,
      birthdate: req.body.birthdate,
      country: req.body.country,
      password: hashedpass,
      email: req.body.email

    })

    res.redirect("/welcome")
    User.save()
      // User.findOneAndUpdate(
      //   {
      //     email:email // search query
      //   }, 

      //   {
      //     User,
      //     // firstname: req.body.firstname,
      //     // lastname: req.body.lastname,
      //     // fullname: req.body.firstname + ' ' + req.body.lastname,
      //     // birthday: req.body.birthday,
      //     // country: req.body.country,
      //     // password: req.body.password               // field:values to update
      //   },

      //   {
      //     new: true,                                // return updated doc
      //     runValidators: true                       // validate before update
      //   })
      .then(doc => {
        // console.log(user.firstname);
        console.log("User added successfully")
      })
      .catch(err => {
        console.error(err)
      })
  })
}

const login1 = (req, res) => {

  user.findOne({email:req.body.email})
  .then(user => {
    if (user) {
      bcrypt.compare(user.email,user.email, function(err, result){
        if(err){
          res.json({
            error:err
          })
        }
        if(result){
          let token = jwt.sign({email : user.email},"verySecretValue",{expiresIn:"2h"})
          res.json({
            message:"login successful!",
            token:token
          })
        }
        // else{
        //   res.json({
        //     message:"Password incorrect!"
        //   })
        // }
        
      })
    }
    else
    {
      res.json({
        message:"no user found!"
      })
    }


  })
}

const register2 = async (req, res)=>{
  try{
    const hashedpassword = await bcrypt.hash(req.body.password,10)

    let User = new user({
      firstname: req.body.firstname,
      lastname: req.body.lastname,
      fullname: req.body.firstname + ' ' + req.body.lastname,
      birthdate: req.body.birthdate,
      country: req.body.country,
      password: hashedpassword,
      email: req.body.email
    })
    User.save()
    res.redirect("/welcome")
    console.log(User);
  } catch {
    res.redirect("/signupform")
  }
}
