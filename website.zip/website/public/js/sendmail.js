const { redirect } = require('express/lib/response');
var nodemailer = require('nodemailer');
const user  = require("../js/userschema")
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const formidable = require('formidable');


exports.sendMail = async function(req,res){
    const {email }= req.body;
    if(email){
      const User = await user.findOne({email: email})
      if(User){
        res.send("email already exists")
      }else{
        if (email){
          try {
            const doc = new user({
              email: email,
            })
            // console.log(doc._id);
            await doc.save()
            const User = await user.findOne({email: email})
            const token = jwt.sign({id: User._id},"randomString", {expiresIn: "10m"})
            const Update = await user.findByIdAndUpdate(User._id,{$set: {token:token}})
            const link = `http://localhost:8080/signupform/${doc._id}/${token}`



            var transporter = nodemailer.createTransport({
              service: 'gmail',
              auth: {
                user: 'vkrunal7575@gmail.com',
                pass: 'lhgjwgbceahmmqbf'
              }
            });
            var mailOptions = {
              from: 'vkrunal7575@gmail.com',
              to: req.body.email,
              subject: 'Create account',
              html: `<h1>Click Here For Create Account</h1>
                      <a href=${link}>click here</a>
                      <p> Link expire in 10 minutes </p>`};


            transporter.sendMail(mailOptions, function(error, info){
              if (error) {
                console.log(error);
              } else {
                  console.log('Email sent: ' + info.response);
                  res.status(200).send("email sent successfully")
                  .catch(err => {
                    res.json({
                      message:"An error occurred!"
                    })
                  })
              }
            });
          } catch (error) {
            
          }
        }
      }
    }
}


exports.forgot = async function(req,res){
  
  const {email }= req.body;
  if(email){
    const User = await user.findOne({email: email})
    if(!User){
      res.send("Account does not exist")
    }else{
      if (email){
          const User = await user.findOne({email: email})
          // console.log(User._id);
          console.log(User.password);
          const token = jwt.sign({id: User._id},"randomString", {expiresIn: "10m"})
          const Update = await user.findByIdAndUpdate(User._id,{$set: {token:token}})
          const link = `http://localhost:8080/forgot/${User._id}/${token}`
          var transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
              user: 'vkrunal7575@gmail.com',
              pass: 'lhgjwgbceahmmqbf'
            }
          });
          var mailOptions = {
            from: 'vkrunal7575@gmail.com',
            to: req.body.email,
            subject: 'Reset Password',
            html: `<h1>Click Here For Create Account</h1>
                    <a href=${link}>click here</a>
                    <p> Link expire in 10 minutes </p>`
          };
          
          transporter.sendMail(mailOptions, function(error, info){
            if (error) {
              console.log(error);
            } else {
                console.log('Email sent: ' + info.response); 
                res.status(200).send("email sent successfully")
                .catch(err => {
                  res.json({
                    message:"An error occurred!"
                  })
                })
            }
          });
        
      }
    }
  }
}


exports.forgotpassword = async function(req, res) {
  const{Newpassword,Confirmpassword,hiddenUserid,hiddentoken} =req.body;
  const id = hiddenUserid; 
  const token = hiddentoken;
  if(Newpassword==Confirmpassword){
    const salt = await bcrypt.genSalt(10);
    const hashpassword = await bcrypt.hash(Confirmpassword,salt);

    const token = jwt.sign({id: id},"randomString", {expiresIn: "24h"})
    res.cookie("login" ,token, {MaxAge: 24 * 60 * 60 ,httpOnly: true, secure: true})
    await user.findOneAndUpdate({_id:id}, {$set: {password:hashpassword,token:token}});
    try {
      const check = jwt.verify(token,"randomString",(err,verify) => {
        if (err) {
          res.send("err: "+ err)
        } else {
          res.redirect("/welcome")
        }
      });
    } catch (error) {
      res.send("Error"+error)
    }
    }else{
      // res.redirect("/forgot/:token")
      res.json({message:"Confirm password are not same as New password"})
    }
}
  
