const mongoose = require('mongoose')


var userschema = new mongoose.Schema({
    firstname:String,
    lastname:String,
    fullname:String,
    birthdate:String,
    country: String,
    password: String,
    email: String,
    token:{type:String , default:''},
    hiddenUserid:String,
    hiddentoken:String,
    
})

var user = mongoose.model('Detail', userschema)
module.exports = user;

